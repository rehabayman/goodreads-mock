module.exports={
    secret: "goodreads-node-secret-key"
}